package com.example.wall_paper

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
